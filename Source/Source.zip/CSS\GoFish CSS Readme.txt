The folder contains the CSS file that can be modified to control how
the VFP Code view is rendered in the GoFish form.

The file used by GoFish to render the colors in the code is: GoFish.css

This folder also contains 2 other css files that are simply templates to get
you started with modifying the css, if you desire to do so.

You have these 2 templates:

GoFish - Black.css
GoFish - Color.css

Choose which one you want to use, and *COPY* it to a file named "GoFish.css" in this
same directory. You may then modify the new GoFish.css to color you code to your own preferences.


Again, neither of these 2 templates are actually used by GoFish. Only a file name GoFish.css is used
at run time.

GoFish.css  <-- This is the css file name that will be used by GoFish


Please keep the original template files intact so you can re-copy them if you mess up
the GoFish.css file.

Enjoy!!


Also, do not remove or modify the GoFish.js file. It contains some JavaScript code that is
used to center the highlighted match line in the browser view. Not intended for user editing,
unleas you really know what you're doing.




